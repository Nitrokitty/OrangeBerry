#  OrangeBerry
The Sweet Cognito Forms Helper!

![enter image description here](https://github.com/Nitrokitty/OrangeBerry/blob/master/Images/logo.png?raw=true)

## How to install
- Download [OrangeBerry.zip](https://github.com/Nitrokitty/OrangeBerry/raw/master/OrangeBerry.zip) file
- Extract the contents
- Open Chrome
- In tab, goto [chrome://extensions](chrome://extensions)
- "Enable Developer Mode" in upper right corner
- Click "Load Unpacked"
- Select the unzipped OrangeBerry folder (it will look like nothing happened)
- Refresh page
- You should now see the OrangeBerry icon with your extensions
